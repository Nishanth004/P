# server/main.py
from flask import Flask, request, jsonify, Response
import logging
import time
import threading
import os
from concurrent.futures import ThreadPoolExecutor
import sys
import signal
import json
import numpy as np
from pydantic import BaseModel, ValidationError, constr, conint, conlist, Json
import random

# Server components
from . import crypto_manager
from . import model_manager
from .config import (
    SERVER_HOST, SERVER_PORT, NUM_ROUNDS, MIN_CLIENTS_FOR_AGGREGATION, ROUND_TIMEOUT_SECONDS,
    PRECISION_FACTOR, MODEL_FEATURE_COUNT, LOG_LEVEL, LOG_FORMAT
    # Removed NUM_CLIENTS_FOR_SPLIT as it's not needed directly in main
)

# --- Logging Setup ---
logging.basicConfig(level=getattr(logging, LOG_LEVEL, logging.INFO),
                    format=LOG_FORMAT,
                    handlers=[logging.StreamHandler(sys.stdout)])
logger = logging.getLogger("orchestrator")
logging.getLogger("werkzeug").setLevel(logging.WARNING); logging.getLogger("requests").propagate = False
logging.getLogger("urllib3").propagate = False; logging.getLogger("phe").setLevel(logging.WARNING)
logging.getLogger("sklearn").setLevel(logging.WARNING); logging.getLogger("pandas").setLevel(logging.WARNING)

# --- Pydantic Models ---
class RegisterPayload(BaseModel): client_id: constr(min_length=1, max_length=100)
class EncryptedDataPayload(BaseModel):
    encrypted_weighted_vector: conlist(dict, min_items=MODEL_FEATURE_COUNT + 1, max_items=MODEL_FEATURE_COUNT + 1)
    encrypted_sample_count: dict
class UpdatePayload(BaseModel):
    client_id: constr(min_length=1, max_length=100); round: conint(ge=0); update_payload: Json[EncryptedDataPayload]

# --- Flask App ---
app = Flask(__name__)

# --- Server State & Globals ---
client_registry = {}; round_updates = {}
current_round = -1; global_model = None
server_lock = threading.Lock(); server_state = "INITIALIZING"; shutdown_event = threading.Event()
fl_thread = None; MAX_WORKERS = max(1, os.cpu_count() - 1) if os.cpu_count() else 2
executor = ThreadPoolExecutor(max_workers=MAX_WORKERS, thread_name_prefix='HE_Worker')

# --- Server Initialization ---
def initialize_server():
    global global_model, server_state, current_round
    logger.info("--- Server Initialization ---")
    server_state = "INITIALIZING"
    try: crypto_manager.initialize_keys(); logger.info("HE keys initialized.")
    except Exception as e: logger.critical(f"FATAL HE key init: {e}.", exc_info=True); os._exit(1)
    if not model_manager.load_and_prepare_test_data(): logger.critical("FATAL data prep fail."); os._exit(1)
    logger.info("Test data prepared.")
    try:
        # load_model now respects LOAD_EXISTING_MODEL flag
        global_model = model_manager.load_model()
        _ = model_manager.get_model_weights(global_model); logger.info(f"Model loaded/initialized.")
    except Exception as e: logger.critical(f"FATAL model load/init: {e}", exc_info=True); os._exit(1)
    with server_lock: server_state = "RUNNING"; current_round = 0
    logger.info("--- Server Initialized Successfully and RUNNING ---")

# --- Flask Routes ---
# (Error handler, healthz, register, status, get_model, submit_update remain the same
# as the previous version - no changes needed here)
@app.errorhandler(Exception)
def handle_exception(e): logger.error(f"Unhandled exception: {e}", exc_info=True); return jsonify({"error": "Internal server error."}), 500
@app.route('/healthz', methods=['GET'])
def health_check():
    with server_lock: state_ok = server_state not in ["INITIALIZING", "SHUTTING_DOWN"]
    data_ok = model_manager.X_test_scaled is not None
    status_code = 200 if state_ok and data_ok else 503
    return jsonify({"status": "OK" if state_ok and data_ok else "Error", "server_state": server_state, "data_loaded": data_ok}), status_code

@app.route('/register', methods=['POST'])
def register_client():
    try: payload = RegisterPayload(**request.json); client_id = payload.client_id
    except Exception as e: logger.warning(f"Reg validation fail: {e}"); return jsonify({"error": "Invalid payload"}), 400
    with server_lock:
        if server_state not in ["RUNNING", "INITIALIZING"]: return jsonify({"error": f"Server not accepting regs (state: {server_state})"}), 503
        client_registry[client_id] = time.time()
        logger.info(f"Client {client_id} registered/updated.")
    try: pub_key_json = crypto_manager.get_public_key_json(); return jsonify({"message": "Registered", "public_key": pub_key_json, "feature_count": MODEL_FEATURE_COUNT, "precision_factor": PRECISION_FACTOR})
    except Exception as e: logger.error(f"Error in reg response: {e}"); return jsonify({"error": "Server error"}), 500

@app.route('/status', methods=['GET'])
def get_status():
    client_id = request.args.get('client_id', 'unknown'); logger.debug(f"Status request from {client_id}")
    with server_lock: state_info = {"state": server_state, "current_round": current_round, "num_rounds_configured": NUM_ROUNDS}
    return jsonify(state_info)

@app.route('/get_model', methods=['GET'])
def get_model():
    client_id = request.args.get('client_id'); request_round_str = request.args.get('round')
    if not client_id: return jsonify({"error": "client_id required"}), 400
    if not request_round_str: return jsonify({"error": "round required"}), 400
    try: request_round = int(request_round_str); assert request_round >= 0
    except: return jsonify({"error": "Invalid round"}), 400
    with server_lock: server_state_local = server_state; current_round_local = current_round; is_registered = client_id in client_registry
    if not is_registered: logger.warning(f"Model request from non-registered {client_id}")
    if server_state_local != "RUNNING": return jsonify({"error": f"Server not RUNNING ({server_state_local})", "state": server_state_local, "current_round": current_round_local}), 400
    if request_round != current_round_local: return jsonify({"error": f"Wrong round ({request_round}), server is {current_round_local}", "state": server_state_local, "current_round": current_round_local}), 400
    global global_model
    if global_model is None: logger.error("Global model is None!"); return jsonify({"error": "Model unavailable"}), 500
    try: model_weights = model_manager.get_model_weights(global_model); logger.info(f"Sending model (round {current_round_local}) to {client_id}"); return jsonify({ "round": current_round_local, "weights": model_weights.tolist(), "state": server_state_local })
    except Exception as e: logger.error(f"Error getting weights: {e}"); return jsonify({"error": "Server error getting weights"}), 500

@app.route('/submit_update', methods=['POST'])
def submit_update():
    try: payload = UpdatePayload(**request.json); client_id = payload.client_id; round_num = payload.round; encrypted_update_payload_json = payload.update_payload.json()
    except Exception as e: logger.warning(f"Update validation fail: {e}"); return jsonify({"error": "Invalid payload"}), 400
    with server_lock: server_state_local = server_state; current_round_local = current_round; is_registered = client_id in client_registry
    if not is_registered: logger.warning(f"Update from non-registered {client_id}"); return jsonify({"error": "Client not registered"}), 403
    if server_state_local != "RUNNING": return jsonify({"error": f"Server not accepting updates ({server_state_local})"}), 503
    if round_num != current_round_local: return jsonify({"error": f"Wrong round ({round_num}), server is {current_round_local}"}), 400
    with server_lock:
        if current_round_local not in round_updates: round_updates[current_round_local] = {}
        round_updates[current_round_local][client_id] = encrypted_update_payload_json
        num_received = len(round_updates[current_round_local])
    logger.info(f"Received update from {client_id} for round {current_round_local}. Total: {num_received}")
    return jsonify({"message": "Update received", "state": server_state_local}), 200

# --- Federated Learning Process ---
# (aggregate_and_decrypt_task remains the same)
def aggregate_and_decrypt_task(updates_this_round, current_round_num):
    log_extra = {'round': current_round_num, 'task': 'agg_decrypt'}
    logger.info(f"Starting task with {len(updates_this_round)} updates.", extra=log_extra)
    task_start_time = time.time()
    encrypted_weighted_updates, encrypted_sample_counts, valid_update_count = [], [], 0
    for client_id, payload_json_str in updates_this_round.items():
        try: inner_payload = EncryptedDataPayload.parse_raw(payload_json_str); encrypted_weighted_updates.append(inner_payload.encrypted_weighted_vector); encrypted_sample_counts.append(inner_payload.encrypted_sample_count); valid_update_count += 1
        except Exception as e: logger.warning(f"Skipping update from {client_id}: Parse error - {e}", extra={'client_id': client_id, **log_extra}); continue
    if valid_update_count < MIN_CLIENTS_FOR_AGGREGATION: logger.warning(f"Insufficient updates ({valid_update_count}). Abort.", extra=log_extra); return None, None
    logger.info(f"Aggregating {valid_update_count} valid updates.", extra=log_extra)
    aggregated_encrypted_weighted_update, aggregated_encrypted_count = None, None
    try:
        agg_start_time = time.time()
        aggregated_encrypted_weighted_update = crypto_manager.aggregate_encrypted_vectors(encrypted_weighted_updates)
        single_value_vectors = [[count_dict] for count_dict in encrypted_sample_counts]
        aggregated_count_vector = crypto_manager.aggregate_encrypted_vectors(single_value_vectors)
        if aggregated_count_vector: aggregated_encrypted_count = aggregated_count_vector[0]
        logger.info(f"Aggregation successful ({time.time()-agg_start_time:.2f}s).", extra=log_extra)
        if aggregated_encrypted_weighted_update is None or aggregated_encrypted_count is None: raise RuntimeError("HE Aggregation failed.")
    except Exception as e: logger.error(f"Aggregation error: {e}", exc_info=True, extra=log_extra); return None, None
    try:
        dec_start_time = time.time()
        decrypted_sum_weighted_delta = crypto_manager.decrypt_vector(aggregated_encrypted_weighted_update)
        decrypted_total_samples = crypto_manager.decrypt_value(aggregated_encrypted_count)
        logger.info(f"Decryption successful ({time.time()-dec_start_time:.2f}s).", extra=log_extra)
        expected_len = MODEL_FEATURE_COUNT + 1
        assert isinstance(decrypted_sum_weighted_delta, list) and len(decrypted_sum_weighted_delta) == expected_len, "Delta vector validation failed"
        assert isinstance(decrypted_total_samples, int) and decrypted_total_samples >= 0, "Sample count validation failed"
        logger.info(f"Task completed ({time.time()-task_start_time:.2f}s).", extra=log_extra)
        return decrypted_sum_weighted_delta, decrypted_total_samples
    except Exception as e: logger.error(f"Decryption/Validation error: {e}", exc_info=True, extra=log_extra); return None, None


def run_federated_round(round_num):
    global global_model, server_state, round_updates
    logger.info(f"--- Starting Round {round_num} ---")
    log_extra = {'round': round_num}

    # --- Evaluate model at START of round ---
    model_manager.evaluate_global_model(global_model, f"{round_num}-Start")

    logger.info(f"Waiting up to {ROUND_TIMEOUT_SECONDS}s for updates...", extra=log_extra)
    round_start_time = time.time()
    while time.time() - round_start_time < ROUND_TIMEOUT_SECONDS:
        if shutdown_event.is_set(): logger.warning("Shutdown signal. Abort round.", extra=log_extra); return False
        time.sleep(5)
    with server_lock: updates_this_round = round_updates.get(round_num, {}).copy()
    num_final_updates = len(updates_this_round)
    logger.info(f"Round {round_num} ended. Received {num_final_updates} updates.", extra=log_extra)
    if num_final_updates < MIN_CLIENTS_FOR_AGGREGATION: logger.warning("Insufficient updates. Skip update.", extra=log_extra); return True
    with server_lock: server_state = "AGGREGATING"
    logger.info("Submitting aggregation task...", extra=log_extra)
    future = executor.submit(aggregate_and_decrypt_task, updates_this_round, round_num)
    try:
        result_timeout = ROUND_TIMEOUT_SECONDS * 1.5
        decrypted_sum_weighted_delta, decrypted_total_samples = future.result(timeout=result_timeout)
        if decrypted_sum_weighted_delta is not None and decrypted_total_samples is not None:
            logger.info("Aggregation/Decryption task successful.", extra=log_extra)
            # No need to evaluate before update here, already did at round start
            with server_lock: server_state = "UPDATING"
            logger.info("Updating global model...", extra=log_extra)
            update_start_time = time.time()
            updated_model_obj = model_manager.update_global_model(decrypted_sum_weighted_delta, decrypted_total_samples)
            update_duration = time.time() - update_start_time
            if updated_model_obj:
                global_model = updated_model_obj # Update in-memory model
                logger.info(f"Model update successful ({update_duration:.2f}s).", extra=log_extra)
                # --- Evaluate AFTER update ---
                model_manager.evaluate_global_model(global_model, f"{round_num}-After")
            else: logger.error("Model update process failed.", extra=log_extra)
        else: logger.error("Aggregation/decryption failed. Skip update.", extra=log_extra)
    except TimeoutError: logger.error(f"Timeout waiting for result (>{result_timeout}s).", extra=log_extra)
    except Exception as e: logger.error(f"Error processing result: {e}", exc_info=True, extra=log_extra)
    finally:
        with server_lock:
            round_updates.pop(round_num, None)
            if server_state not in ["FINISHED", "SHUTTING_DOWN"]: server_state = "RUNNING"
        logger.info(f"--- Round {round_num} Complete ---", extra=log_extra)
        return True

def federated_learning_process():
    global server_state, current_round
    time.sleep(2) # Wait for server init/model load
    for r in range(NUM_ROUNDS):
        if shutdown_event.is_set(): logger.info("Shutdown signal. Exit FL process."); break
        with server_lock: current_round = r; server_state = "RUNNING"
        logger.info(f"Starting round {r} processing...")
        success = run_federated_round(r) # Includes evaluation
        if not success: logger.warning(f"Round {r} terminated early."); break
        if r < NUM_ROUNDS - 1: time.sleep(2 + random.uniform(0,1))
    logger.info("FL process finished.")
    with server_lock:
        final_state = "SHUTTING_DOWN" if shutdown_event.is_set() else "FINISHED"
        logger.info(f"Setting final state: {final_state}. Last round: {current_round}")
        server_state = final_state
    # --- Print Final Evaluation Summary ---
    model_manager.print_evaluation_summary()
    # --- End Summary ---
    if final_state == "FINISHED": logger.info("Server remains active.")

def signal_handler(signum, frame):
    global server_state
    logger.warning(f"Signal {signum} received. Shut down...");
    with server_lock:
        if server_state == "SHUTTING_DOWN": return
        server_state = "SHUTTING_DOWN"
    shutdown_event.set(); logger.info("Shutting down executor...");
    # Wait briefly for crypto tasks, but not indefinitely
    executor.shutdown(wait=True, cancel_futures=False) # Wait for tasks like crypto
    logger.info("Executor shut down.")
    logger.info("Requesting server exit."); os._exit(0) # Force exit for dev server

# --- Main Execution ---
if __name__ == '__main__':
    try:
        initialize_server()
        signal.signal(signal.SIGINT, signal_handler); signal.signal(signal.SIGTERM, signal_handler)
        fl_thread = threading.Thread(target=federated_learning_process, name="FL_Process", daemon=True); fl_thread.start()
        logger.info("FL thread started.")
        logger.info(f"Starting Flask dev server on http://{SERVER_HOST}:{SERVER_PORT}")
        app.run(host=SERVER_HOST, port=SERVER_PORT, threaded=True, use_reloader=False)
    except Exception as e: logger.critical(f"Startup error: {e}", exc_info=True); os._exit(1)
    finally: logger.info("Server exiting."); executor.shutdown(wait=False)
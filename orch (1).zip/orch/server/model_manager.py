# server/model_manager.py
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
from sklearn.exceptions import NotFittedError
import joblib
import os
import logging
import time
import sys
from tabulate import tabulate # Import for table formatting


from .config import (MODEL_FEATURE_COUNT, PRECISION_FACTOR, ILLUSTRATIVE_ACTION_THRESHOLD,
                     MODEL_FILE_PATH, FULL_DATASET_PATH, TARGET_COLUMN, TEST_SET_RATIO,
                     LOAD_EXISTING_MODEL) # Import new flag

logger = logging.getLogger("orchestrator.model")

# --- Global variables for Test Data and Evaluation History ---
X_test_scaled = None
y_test = None
evaluation_history = [] # Store dicts of metrics per evaluation stage

# --- Data Loading and Test Set Preparation ---
def load_and_prepare_test_data():
    """Loads dataset, splits, scales test set, discards train set."""
    global X_test_scaled, y_test
    logger.info(f"Loading dataset for test split: {FULL_DATASET_PATH}")
    try:
        server_dir = os.path.dirname(__file__); absolute_dataset_path = os.path.join(server_dir, FULL_DATASET_PATH)
        if not os.path.exists(absolute_dataset_path): raise FileNotFoundError(f"Not found: {absolute_dataset_path}")
        df = pd.read_csv(absolute_dataset_path); logger.info(f"Dataset loaded. Shape: {df.shape}")
        if df.isnull().sum().sum() > 0:
            logger.warning("Missing values found. Filling with means/modes.")
            for col in df.columns[df.isnull().any()]:
                if pd.api.types.is_numeric_dtype(df[col]): df[col].fillna(df[col].mean(), inplace=True)
                else: df[col].fillna(df[col].mode()[0] if not df[col].mode().empty else 'Unknown', inplace=True)
        if TARGET_COLUMN not in df.columns: raise ValueError(f"Target '{TARGET_COLUMN}' not found.")
        y = df[TARGET_COLUMN].values.astype(int); X = df.drop(columns=[TARGET_COLUMN])
        if X.shape[1] != MODEL_FEATURE_COUNT: raise ValueError(f"Feature count mismatch! Data={X.shape[1]}, Config={MODEL_FEATURE_COUNT}.")
        logger.info(f"Performing train/test split (Test ratio: {TEST_SET_RATIO})...")
        X_train, X_test, _, y_test_local = train_test_split(X, y, test_size=TEST_SET_RATIO, random_state=42, stratify=y)
        y_test = y_test_local
        logger.info("Fitting scaler on training portion (discarded after fit)...")
        scaler = StandardScaler(); scaler.fit(X_train)
        X_test_scaled = scaler.transform(X_test)
        logger.info(f"Test set prepared and scaled. Shape: {X_test_scaled.shape}")
        del X_train, X, y, df, scaler; logger.info("Training data discarded from server memory.")
        return True
    except Exception as e: logger.critical(f"Data prep error: {e}", exc_info=True); return False

# --- Model Persistence ---
def initialize_global_model(feature_count):
    logger.info(f"Initializing NEW model ({feature_count} features)...")
    model = LogisticRegression(warm_start=True, solver='liblinear', max_iter=1, class_weight='balanced')
    dummy_X=np.zeros((2, feature_count)); dummy_y=np.array([0, 1])
    try: model.fit(dummy_X, dummy_y); model.coef_=np.zeros((1, feature_count)); model.intercept_=np.zeros(1)
    except Exception as e: logger.error(f"Dummy fit fail: {e}"); raise RuntimeError from e
    logger.info("Initialized model weights to zero.")
    save_model(model); return model

def load_model():
    """Loads or initializes model based on config flag."""
    if LOAD_EXISTING_MODEL and os.path.exists(MODEL_FILE_PATH):
        logger.info(f"Attempting to load existing model from: {MODEL_FILE_PATH}")
        try:
            model = joblib.load(MODEL_FILE_PATH)
            logger.info("Existing model loaded successfully.")
            # Validation
            if not hasattr(model, 'coef_'): logger.warning("Loaded unfitted model. Reinit."); return initialize_global_model(MODEL_FEATURE_COUNT)
            if model.coef_.shape[1] != MODEL_FEATURE_COUNT: logger.error("Feature mismatch! Reinit."); return initialize_global_model(MODEL_FEATURE_COUNT)
            logger.info("Existing model validated.")
            return model
        except Exception as e:
            logger.error(f"Error loading existing model: {e}. Initializing new model instead.", exc_info=True)
            return initialize_global_model(MODEL_FEATURE_COUNT)
    else:
        if LOAD_EXISTING_MODEL:
             logger.warning(f"LOAD_EXISTING_MODEL is True, but model file not found at {MODEL_FILE_PATH}. Initializing new model.")
        else:
             logger.info("LOAD_EXISTING_MODEL is False. Initializing new model.")
        return initialize_global_model(MODEL_FEATURE_COUNT)

def save_model(model):
    try: joblib.dump(model, MODEL_FILE_PATH); logger.info(f"Saved model to {MODEL_FILE_PATH}."); return True
    except Exception as e: logger.error(f"Error saving model: {e}"); return False

# --- Weight Handling ---
def get_model_weights(model):
    if not hasattr(model, 'coef_') or not hasattr(model, 'intercept_'): raise NotFittedError("Model not fitted.")
    coef=model.coef_.reshape(1,-1) if model.coef_.ndim==1 else model.coef_
    intercept=np.array([model.intercept_]).flatten() if not isinstance(model.intercept_, np.ndarray) else model.intercept_.flatten()
    return np.concatenate([coef.flatten(), intercept])

def set_model_weights(model, weights):
    if not hasattr(model, 'coef_') or not hasattr(model, 'intercept_'): raise NotFittedError("Model not fitted/init.")
    expected_fc=model.coef_.shape[1]; expected_size=expected_fc + 1
    if len(weights) != expected_size: raise ValueError(f"Weights length mismatch: Exp={expected_size}, Got={len(weights)}")
    try:
        model.coef_=weights[:expected_fc].reshape(1, expected_fc); model.intercept_=weights[expected_fc:].reshape(1,)
        if not hasattr(model, 'classes_') or not np.array_equal(model.classes_, [0, 1]): model.classes_=np.array([0, 1])
    except Exception as e: raise ValueError(f"Failed set weights: {e}") from e
    return model

# --- Update Logic ---
def update_global_model(aggregated_decrypted_weighted_updates, total_sample_count):
    if total_sample_count <= 0: logger.warning(f"Cannot update: samples={total_sample_count}."); return load_model()
    # Load model fresh before update to ensure we have the latest saved state
    current_model = load_model()
    if not current_model: logger.error("Failed load model for update."); return None # Critical error if loading fails
    try:
        current_weights = get_model_weights(current_model)
        sum_scaled_weighted_updates = np.array(aggregated_decrypted_weighted_updates)
        average_weighted_update = (sum_scaled_weighted_updates / PRECISION_FACTOR) / total_sample_count
        logger.debug(f"Update norm: {np.linalg.norm(average_weighted_update):.4f}")
        new_weights = current_weights + average_weighted_update
        # Apply weights to the currently loaded model object
        updated_model = set_model_weights(current_model, new_weights)
        # Save the updated model object
        if save_model(updated_model):
            logger.info(f"Global model updated (Samples: {total_sample_count}).")
            return updated_model # Return the updated object
        else:
            logger.error("Failed save updated model!"); return None
    except Exception as e: logger.error(f"Failed model update: {e}", exc_info=True); return None

# --- Evaluation ---
def evaluate_global_model(model, eval_stage=""):
    """Evaluates model on test set, logs metrics, stores history."""
    global X_test_scaled, y_test, evaluation_history
    log_extra = {'eval_stage': eval_stage, 'task': 'evaluation'}
    if model is None or X_test_scaled is None or y_test is None or len(X_test_scaled)==0:
        logger.error("Cannot eval: Model/Test data missing or empty.", extra=log_extra); return

    title_stage = f"({eval_stage})" if eval_stage else ""
    logger.info(f"--- Evaluating Model {title_stage} ---", extra=log_extra)
    metrics = {"Stage": eval_stage} # Dict to store metrics
    try:
        start_time = time.time(); y_pred = model.predict(X_test_scaled); y_pred_proba = None; auc = float('nan')
        try: y_pred_proba = model.predict_proba(X_test_scaled)[:, 1]
        except: logger.warning("predict_proba failed. AUC unavailable.", extra=log_extra)

        metrics["Accuracy"] = accuracy_score(y_test, y_pred)
        metrics["Precision"] = precision_score(y_test, y_pred, zero_division=0)
        metrics["Recall"] = recall_score(y_test, y_pred, zero_division=0)
        metrics["F1-Score"] = f1_score(y_test, y_pred, zero_division=0)

        if y_pred_proba is not None and len(np.unique(y_test)) > 1:
             try: metrics["ROC_AUC"] = roc_auc_score(y_test, y_pred_proba)
             except ValueError as auc_err: logger.warning(f"AUC calc error: {auc_err}"); metrics["ROC_AUC"] = auc
        else: metrics["ROC_AUC"] = auc

        eval_time = time.time() - start_time
        metrics["Eval Time (s)"] = f"{eval_time:.2f}"

        # Log individual metrics clearly
        logger.info(f"Evaluation Metrics {title_stage}:", extra=log_extra)
        for key, value in metrics.items():
            if key != "Stage" and key != "Eval Time (s)": # Format floats
                 logger.info(f"  {key:<10}: {value:.4f}", extra=log_extra)
        logger.info(f"  Eval Time: {metrics['Eval Time (s)']}s", extra=log_extra)

        # Store results
        evaluation_history.append(metrics)

        # Illustrative action check
        if eval_stage.endswith("After") and y_pred_proba is not None:
            avg_risk_prob = np.mean(y_pred_proba)
            if avg_risk_prob > ILLUSTRATIVE_ACTION_THRESHOLD:
                logger.warning(f"ILLUSTRATIVE ACTION TRIGGER: Avg risk {avg_risk_prob:.4f} > {ILLUSTRATIVE_ACTION_THRESHOLD}.")
                print("\n"+"="*60+"\n   ⚠️  SIMULATING ACTION (Based on Heart Risk Model) ⚠️\n"+"="*60+"\n")

    except Exception as e: logger.error(f"Error during evaluation: {e}", exc_info=True, extra=log_extra)
    finally: logger.info("--- Evaluation Complete ---", extra=log_extra)

def print_evaluation_summary():
    """Prints the collected evaluation history as a table."""
    if not evaluation_history:
        logger.info("No evaluation history collected to print.")
        return

    # Prepare data for tabulate
    headers = evaluation_history[0].keys()
    rows = [list(h.values()) for h in evaluation_history]

    # Format floats in rows
    formatted_rows = []
    for row in rows:
        formatted_row = []
        for i, item in enumerate(row):
             header = list(headers)[i]
             if isinstance(item, float) and header not in ["Eval Time (s)"]:
                 formatted_row.append(f"{item:.4f}")
             else:
                 formatted_row.append(item)
        formatted_rows.append(formatted_row)

    print("\n" + "="*80)
    print(" " * 25 + "FEDERATED LEARNING EVALUATION SUMMARY")
    print("="*80)
    try:
        print(tabulate(formatted_rows, headers=headers, tablefmt="grid"))
    except ImportError:
        logger.warning("`tabulate` library not installed. Cannot print summary table. Use `pip install tabulate`.")
        # Fallback: Print basic history
        for row in evaluation_history:
            print(row)
    print("="*80 + "\n")
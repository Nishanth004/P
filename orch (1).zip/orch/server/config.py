# server/config.py
import os
import logging
import secrets
import sys

# --- Configuration ---
logger = logging.getLogger("orchestrator_config")

# --- Network Configuration ---
SERVER_HOST = '0.0.0.0'
SERVER_PORT = 5000

# --- Data Configuration (Server holds Test Set Only) ---
FULL_DATASET_PATH = 'heart_attack_prediction_dataset.csv' # <<<--- MUST EXIST IN server/
TARGET_COLUMN = 'Heart Attack Risk'
TEST_SET_RATIO = 0.20
# How many ways the conceptual training data is split for clients (used for mapping ID)
# This value is NOT used by server logic directly anymore but needed for client mapping.
# Client config also needs NUM_ROUNDS to calculate its slice index.
NUM_CLIENTS_FOR_SPLIT = 5 # Example value

# --- Federated Learning Configuration ---
NUM_ROUNDS = 5
MIN_CLIENTS_FOR_AGGREGATION = 1
ROUND_TIMEOUT_SECONDS = 60

# --- Homomorphic Encryption Configuration ---
HE_KEY_SIZE = 2048
PRECISION_FACTOR = 10**6
HE_PUBLIC_KEY_PATH = 'server_he_public.key'
HE_PRIVATE_KEY_PATH = 'server_he_private.key'

# --- Model Configuration ---
MODEL_FEATURE_COUNT = 21 # Based on heart attack dataset (22 total cols - 1 target)
MODEL_FILE_PATH = 'global_model_heart.pkl'
# --- NEW: Option to load existing model or start fresh ---
LOAD_EXISTING_MODEL = False # Set to False to force re-initialization

# --- Logging ---
LOG_LEVEL = 'INFO'
LOG_FORMAT = '%(asctime)s - %(name)s:%(levelname)s - %(message)s'

# --- Autonomous Action (Illustrative Only) ---
ILLUSTRATIVE_ACTION_THRESHOLD = 0.75


# --- Validation & Logging ---
server_dir = os.path.dirname(__file__)
absolute_dataset_path = os.path.join(server_dir, FULL_DATASET_PATH)
if not os.path.exists(absolute_dataset_path):
     print(f"ERROR: Dataset file not found at {absolute_dataset_path}. Server cannot start.", file=sys.stderr)
     sys.exit(1)

print("--- Server Configuration (Client Owns Data / Server Test Set) ---")
print(f"  Network: Host={SERVER_HOST}, Port={SERVER_PORT}")
print(f"  Dataset: Path={FULL_DATASET_PATH}, Target={TARGET_COLUMN}, TestRatio={TEST_SET_RATIO}")
# print(f"  Client Data Split Count (Concept): {NUM_CLIENTS_FOR_SPLIT}") # Commented out - server doesn't use it directly
print(f"  FL: Rounds={NUM_ROUNDS}, MinClients={MIN_CLIENTS_FOR_AGGREGATION}, Timeout={ROUND_TIMEOUT_SECONDS}s")
print(f"  HE: KeySize={HE_KEY_SIZE}, Precision={PRECISION_FACTOR}")
print(f"  HE Keys: Pub='{HE_PUBLIC_KEY_PATH}', Priv='{HE_PRIVATE_KEY_PATH}'")
print(f"  Model: Features={MODEL_FEATURE_COUNT}, File='{MODEL_FILE_PATH}'")
print(f"  LOAD_EXISTING_MODEL: {LOAD_EXISTING_MODEL}") # Log the new option
print(f"  Logging: Level={LOG_LEVEL}")
print(f"  Action Threshold: {ILLUSTRATIVE_ACTION_THRESHOLD} (Illustrative)")
print("----------------------------------------------------------------")
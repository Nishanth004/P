# server/crypto_manager.py
import phe as paillier
import json
import logging
import os
import time
from threading import Lock

# Assuming config is loaded correctly elsewhere
from .config import HE_KEY_SIZE, HE_PUBLIC_KEY_PATH, HE_PRIVATE_KEY_PATH

logger = logging.getLogger("orchestrator.crypto") # Child logger

public_key, private_key = None, None
key_lock = Lock()

def _save_key_to_file(key_data, filepath):
    """Saves key data (dict) to a JSON file."""
    try:
        # --- FIX START ---
        # Only create directories if the filepath includes them
        dir_name = os.path.dirname(filepath)
        if dir_name: # Check if dirname is not empty
            os.makedirs(dir_name, exist_ok=True)
        # --- FIX END ---

        with open(filepath, 'w') as f:
            json.dump(key_data, f)
        logger.info(f"Saved key component to {filepath}")
    except Exception as e:
        logger.error(f"Failed to save key to {filepath}: {e}", exc_info=True)
        raise

def _load_key_from_file(filepath):
    """Loads key data (dict) from a JSON file."""
    if not os.path.exists(filepath): return None
    try:
        with open(filepath, 'r') as f: key_data = json.load(f)
        logger.info(f"Loaded key component from {filepath}")
        return key_data
    except Exception as e:
        logger.error(f"Failed to load key from {filepath}: {e}", exc_info=True)
        return None

def generate_and_save_keys():
    """Generates and saves Paillier key pair."""
    global public_key, private_key
    logger.warning(f"Generating new Paillier keys (Size: {HE_KEY_SIZE})...")
    start_time = time.time()
    try:
        pub, priv = paillier.generate_paillier_keypair(n_length=HE_KEY_SIZE)
        pub_data = {'n': str(pub.n)}
        if hasattr(priv, 'p') and hasattr(priv, 'q'):
             priv_data = {'p': str(priv.p), 'q': str(priv.q)}
        else: raise AttributeError("Cannot serialize private key components p,q.")

        _save_key_to_file(pub_data, HE_PUBLIC_KEY_PATH)
        _save_key_to_file(priv_data, HE_PRIVATE_KEY_PATH)
        public_key, private_key = pub, priv
        logger.info(f"Key pair generated and saved ({time.time() - start_time:.1f}s).")
    except Exception as e:
        logger.critical(f"HE key generation/saving failed: {e}", exc_info=True)
        public_key, private_key = None, None
        raise RuntimeError("HE key generation/saving failed.") from e
    return public_key, private_key

def load_keys_from_files():
    """Loads Paillier key pair from files."""
    global public_key, private_key
    logger.info("Loading HE keys from files...")
    pub_data = _load_key_from_file(HE_PUBLIC_KEY_PATH)
    priv_data = _load_key_from_file(HE_PRIVATE_KEY_PATH)
    if pub_data and pub_data.get('n') and priv_data and priv_data.get('p') and priv_data.get('q'):
        try:
            n = int(pub_data['n']); p = int(priv_data['p']); q = int(priv_data['q'])
            public_key = paillier.PaillierPublicKey(n=n)
            private_key = paillier.PaillierPrivateKey(public_key, p, q)
            logger.info("HE keys loaded successfully.")
            return public_key, private_key
        except Exception as e:
            logger.error(f"Failed to reconstruct keys from data: {e}", exc_info=True)
            public_key, private_key = None, None
            return None, None
    else:
        logger.warning("Could not load keys (files missing or incomplete).")
        return None, None

def initialize_keys():
    """Initializes keys, loading or generating as needed."""
    with key_lock:
        if public_key and private_key: return public_key, private_key
        pub, priv = load_keys_from_files()
        if pub and priv: return pub, priv
        logger.warning("Generating new HE keys.")
        return generate_and_save_keys()

def get_public_key():
    if not public_key: initialize_keys()
    if not public_key: raise RuntimeError("HE Public Key unavailable.")
    return public_key

def get_private_key():
    if not private_key: initialize_keys()
    if not private_key: raise RuntimeError("HE Private Key unavailable.")
    return private_key

def get_public_key_json():
    """Returns public key for JSON response."""
    pub_key = get_public_key()
    return {'n': str(pub_key.n)}

def _deserialize_encrypted_number(pub_key, enc_data_dict):
     """Helper to deserialize JSON dict to EncryptedNumber."""
     if not isinstance(enc_data_dict, dict) or 'ciphertext' not in enc_data_dict or 'exponent' not in enc_data_dict:
         raise ValueError(f"Invalid encrypted data format: {enc_data_dict}")
     try:
        return paillier.EncryptedNumber(pub_key, int(enc_data_dict['ciphertext']), int(enc_data_dict['exponent']))
     except Exception as e:
        raise ValueError(f"Deserialization error: {e}") from e

def decrypt_value(encrypted_value_dict):
    """Decrypts a single encrypted value (dict)."""
    priv_key = get_private_key(); pub_key = get_public_key()
    try:
        enc_num = _deserialize_encrypted_number(pub_key, encrypted_value_dict)
        return int(priv_key.decrypt(enc_num))
    except Exception as e:
        logger.error(f"Decryption failed for value: {encrypted_value_dict}. Error: {e}", exc_info=True)
        raise RuntimeError("Decryption failed") from e

def decrypt_vector(encrypted_vector_list):
    """Decrypts a vector of encrypted values (list of dicts)."""
    priv_key = get_private_key(); pub_key = get_public_key()
    decrypted_vector = []
    start_time = time.time()
    for i, item in enumerate(encrypted_vector_list):
        try:
            enc_num = _deserialize_encrypted_number(pub_key, item)
            decrypted_vector.append(int(priv_key.decrypt(enc_num)))
        except Exception as e:
            logger.error(f"Decryption failed for vector element {i}. Error: {e}", exc_info=True)
            raise RuntimeError(f"Decryption failed for element {i}") from e
    logger.debug(f"Decrypted vector length {len(decrypted_vector)} in {time.time()-start_time:.2f}s.")
    return decrypted_vector

def aggregate_encrypted_vectors(encrypted_vector_list_of_lists):
    """Aggregates encrypted vectors using Paillier homomorphism."""
    if not encrypted_vector_list_of_lists: return None
    pub_key = get_public_key()
    aggregated_enc_numbers = None
    vector_len = -1
    start_time = time.time()
    valid_vectors_count = 0

    for i, enc_vec_list in enumerate(encrypted_vector_list_of_lists):
        if not isinstance(enc_vec_list, list):
             logger.warning(f"Skipping aggregation item {i}: not a list.")
             continue
        try:
            current_enc_vector = [_deserialize_encrypted_number(pub_key, item) for item in enc_vec_list]
            if aggregated_enc_numbers is None:
                aggregated_enc_numbers = current_enc_vector
                vector_len = len(aggregated_enc_numbers)
                if vector_len == 0: # Handle empty first vector
                     aggregated_enc_numbers = None
                     logger.warning(f"Skipping item {i}: empty vector provided.")
                     continue
                logger.debug(f"Initialized aggregation with vector {i}, length {vector_len}.")
            else:
                if len(current_enc_vector) != vector_len:
                    logger.warning(f"Skipping vector {i}: length mismatch (Expected {vector_len}, got {len(current_enc_vector)})")
                    continue
                # Add element-wise
                for j in range(vector_len):
                    aggregated_enc_numbers[j] += current_enc_vector[j]
            valid_vectors_count += 1
        except Exception as e:
             logger.error(f"Error processing vector {i} during aggregation: {e}", exc_info=True)
             # Skip this vector, but continue if possible? Or fail hard? Let's skip.
             continue

    if aggregated_enc_numbers:
         serialized_aggregate = [{'ciphertext': str(num.ciphertext(be_secure=False)), 'exponent': num.exponent}
                                 for num in aggregated_enc_numbers]
         logger.debug(f"Aggregated {valid_vectors_count} vectors in {time.time()-start_time:.2f}s.")
         return serialized_aggregate
    else:
        logger.warning("Aggregation resulted in None (no valid vectors?).")
        return None
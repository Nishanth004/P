# client/config.py
import logging
import uuid
import sys
import os

# --- Configuration ---
logger = logging.getLogger(__name__)

# --- Server & Client Identity ---
SERVER_URL = 'https://didactic-spoon-v4x76jq7pjvfxwq4-5000.app.github.dev/'# <<< --- MUST BE EDITED
CLIENT_ID = f"client_{str(uuid.uuid4())[:8]}"

# --- Data Configuration ---
DATASET_PATH = 'heart_attack_prediction_dataset.csv'
TARGET_COLUMN = 'Heart Attack Risk'
NUM_ROUNDS = 5
SAMPLES_PER_ROUND_SLICE = 1000 # Keep this for now, can be reduced if encryption too slow

# --- Training Config (MLP) ---
LOCAL_EPOCHS = 10 # << INCREASED
BATCH_SIZE = 32
LEARNING_RATE = 0.001 # Standard Adam LR

# --- Feature Count ---
FEATURE_COUNT = 21

# --- Logging ---
LOG_LEVEL = 'INFO'

# --- Validation & Logging ---
if SERVER_URL == 'https://your-server-https-url-here/' or not SERVER_URL.startswith('https://'):
     print(f"ERROR: SERVER_URL in client/config.py not set or not HTTPS: {SERVER_URL}", file=sys.stderr)
client_dir = os.path.dirname(__file__); absolute_dataset_path = os.path.join(client_dir, DATASET_PATH)
if not os.path.exists(absolute_dataset_path):
    print(f"ERROR: Dataset file not found at {absolute_dataset_path}. Client cannot train.", file=sys.stderr)

print("--- Client Configuration (MLP Model - Enhanced Capacity) ---")
print(f"  SERVER_URL: '{SERVER_URL}'")
print(f"  CLIENT_ID: {CLIENT_ID}")
print(f"  LOCAL_DATASET_PATH: {DATASET_PATH}")
print(f"  TARGET_COLUMN: {TARGET_COLUMN}")
print(f"  EXPECTED_FEATURES: {FEATURE_COUNT}")
print(f"  TOTAL_ROUNDS_FOR_SLICING: {NUM_ROUNDS}")
print(f"  SAMPLES_PER_ROUND_SLICE: {SAMPLES_PER_ROUND_SLICE or 'Proportional Chunk'}")
print(f"  MLP Training: Epochs={LOCAL_EPOCHS}, Batch={BATCH_SIZE}, LR={LEARNING_RATE}") # Updated print
print(f"  Log Level: {LOG_LEVEL}")
print("----------------------------------------------------------")
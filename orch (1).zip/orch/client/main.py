# client/main.py
import os
os.environ['CUDA_VISIBLE_DEVICES'] = '-1' # Must be before TensorFlow import
import tensorflow as tf # Now safe to import

import requests
import time
import logging
import numpy as np
import sys
import json
# import os # Already imported above
from urllib3.util.retry import Retry
from requests.adapters import HTTPAdapter
import warnings
import random

# Import configuration and modules
from .config import (
    SERVER_URL, CLIENT_ID, LOG_LEVEL,
    LOCAL_EPOCHS, FEATURE_COUNT, NUM_ROUNDS
)
from . import crypto_manager
from . import data_loader
from . import local_trainer

# --- Logging Setup ---
logging.basicConfig(level=getattr(logging, LOG_LEVEL, logging.INFO),
                    format='%(asctime)s - %(name)s:%(levelname)s - CLIENT:'+ CLIENT_ID +' - %(message)s',
                    handlers=[logging.StreamHandler(sys.stdout)])
logger = logging.getLogger(__name__)
logging.getLogger("requests").setLevel(logging.WARNING)
logging.getLogger("urllib3").setLevel(logging.WARNING)
# Suppress TensorFlow INFO and WARNING messages for cleaner output, show ERRORS
tf.get_logger().setLevel('ERROR')


# --- Global State ---
current_client_round = -1
global_model_feature_count = -1
global_model_precision_factor = -1
server_status = {"state": "UNKNOWN", "current_round": -1}

# --- Network Client Setup ---
def create_session():
    session = requests.Session()
    session.verify = True
    retries = Retry(total=4, backoff_factor=0.5, status_forcelist=[500, 502, 503, 504])
    adapter = HTTPAdapter(max_retries=retries)
    session.mount('https://', adapter)
    session.timeout = (15, 60)
    logger.info("Requests session created.")
    return session

session = create_session()

# --- API Interaction Functions ---
def register_with_server():
    global global_model_feature_count, global_model_precision_factor
    url = f"{SERVER_URL.rstrip('/')}/register"; payload={'client_id':CLIENT_ID}
    try:
        logger.info(f"Attempting registration: {url}..."); response=session.post(url,json=payload,timeout=(20,40)); response.raise_for_status()
        data=response.json(); pub_key_json=data.get('public_key'); prec_factor=data.get('precision_factor'); feat_count=data.get('feature_count')
        if not pub_key_json or prec_factor is None or feat_count is None: logger.error(f"Reg response missing data: {data}"); return False
        crypto_manager.set_crypto_params(pub_key_json, prec_factor)
        if crypto_manager.get_public_key() is None: return False
        global_model_feature_count=int(feat_count); global_model_precision_factor=int(prec_factor)
        if global_model_feature_count != FEATURE_COUNT: logger.error(f"FATAL Feature count mismatch! Server={global_model_feature_count}, Client={FEATURE_COUNT}."); return False
        logger.info(f"Registered. Server Config: Features={global_model_feature_count}, Precision={global_model_precision_factor}"); return True
    except requests.exceptions.SSLError as e: logger.error(f"SSL Error: {e}", exc_info=True); return False
    except requests.exceptions.RequestException as e: r=getattr(e,'response',None); logger.error(f"Reg fail (Status: {r.status_code if r else 'N/A'}): {e}", exc_info=True); return False
    except Exception as e: logger.error(f"Reg error: {e}", exc_info=True); return False

def check_server_status():
    global server_status
    url = f"{SERVER_URL.rstrip('/')}/status"
    try:
        response=session.get(url,timeout=(5,15)); response.raise_for_status()
        new_status=response.json()
        if new_status != server_status: logger.info(f"Server status: {new_status}"); server_status=new_status
        else: logger.debug(f"Server status checked: {server_status}")
        return True
    except requests.exceptions.RequestException as e: logger.warning(f"Status check fail: {e}"); server_status={"state":"UNREACHABLE","current_round":-1}; return False
    except Exception as e: logger.error(f"Status check error: {e}", exc_info=True); return False

def get_global_model(round_num):
    url = f"{SERVER_URL.rstrip('/')}/get_model"; params={'client_id':CLIENT_ID,'round':round_num}
    try:
        logger.info(f"Requesting model round {round_num}...")
        response=session.get(url,params=params,timeout=(15,90)); response.raise_for_status()
        data=response.json()
        if data.get('round') != round_num: logger.warning("Model round mismatch."); return None
        if data.get('state') != "RUNNING": logger.warning(f"Server not RUNNING ({data.get('state')})."); return None
        weights=data.get('weights');
        if weights is None: logger.error("Received no weights from server."); return None
        model_weights=np.array(weights)
        logger.info(f"Received model weights, shape: {model_weights.shape}")

        # --- MODIFICATION: Remove strict length check for MLP ---
        # The total number of parameters in an MLP is not simply features + 1.
        # The actual validation of weight structure will happen in local_trainer.set_model_weights
        # expected_len=global_model_feature_count+1
        # if len(model_weights) != expected_len: logger.error(f"Weights length mismatch! Expected {expected_len}, Got {len(model_weights)}."); return None
        # --- END MODIFICATION ---

        return model_weights
    except requests.exceptions.RequestException as e: r=getattr(e,'response',None); logger.error(f"Get model fail (Status: {r.status_code if r else 'N/A'}): {e}", exc_info=True); return None
    except Exception as e: logger.error(f"Error processing model response: {e}", exc_info=True); return None

def submit_encrypted_update(round_num, encrypted_payload_json):
    url = f"{SERVER_URL.rstrip('/')}/submit_update"; payload={'client_id':CLIENT_ID,'round':round_num,'update_payload':encrypted_payload_json}
    try:
        logger.info(f"Submitting update round {round_num}..."); response=session.post(url,json=payload,timeout=(20,120)); response.raise_for_status()
        logger.info("Update submitted successfully."); return True
    except requests.exceptions.RequestException as e: r=getattr(e,'response',None); logger.error(f"Submit update fail (Status: {r.status_code if r else 'N/A'}): {e}", exc_info=True); return False
    except Exception as e: logger.error(f"Update submission error: {e}", exc_info=True); return False

def run_client_round(target_round):
    global current_client_round
    start_round_time = time.time()
    logger.info(f"--- Starting Client Round {target_round} ---")

    global_weights = get_global_model(target_round)
    if global_weights is None: logger.warning("Failed get model."); return False

    logger.info("Loading and processing local data slice for this round...")
    try:
        X_local_scaled, y_local = data_loader.get_client_round_data_slice(CLIENT_ID, target_round)
        if X_local_scaled is None or y_local is None: logger.error("Failed get local data slice."); return False
        sample_count = len(X_local_scaled)
        if sample_count == 0: logger.warning("Local data slice empty."); return True
        logger.info(f"Local data slice loaded/processed. Samples: {sample_count}")
    except Exception as e: logger.error(f"Failed processing local data: {e}", exc_info=True); return False

    logger.info(f"Training local model on {sample_count} samples...")
    start_train_time = time.time()
    try:
        weight_difference = local_trainer.train_local_model(global_weights, X_local_scaled, y_local, CLIENT_ID, global_model_feature_count)
        train_time = time.time() - start_train_time
        if weight_difference is None: logger.warning("Training skipped."); return True
        if np.linalg.norm(weight_difference) < 1e-9: logger.warning("Near-zero weight diff."); weight_difference = np.zeros_like(weight_difference)
        logger.info(f"Local training finished ({train_time:.2f}s). Diff norm: {np.linalg.norm(weight_difference):.4f}")
    except Exception as e: logger.error(f"Local training error: {e}", exc_info=True); return False

    prec_factor = crypto_manager.get_precision_factor(); assert prec_factor is not None
    scaled_weighted_difference = (weight_difference * sample_count * prec_factor).astype(np.int64)

    logger.info("Encrypting update...")
    start_encrypt_time = time.time()
    try: encrypted_payload_json = crypto_manager.encrypt_weighted_update_and_sample_count(scaled_weighted_difference, sample_count)
    except OverflowError as oe: # Catch potential HE overflow
        logger.error(f"OverflowError during encryption: {oe}. This may indicate weights/updates are too large for HE parameters.", exc_info=True)
        logger.error("Consider reducing SAMPLES_PER_ROUND_SLICE, LEARNING_RATE, or PRECISION_FACTOR, or increasing HE_KEY_SIZE (server).")
        return False # Stop this client round
    except Exception as e: logger.error(f"Encryption failed: {e}", exc_info=True); return False
    encrypt_time = time.time() - start_encrypt_time
    logger.info(f"Encryption finished ({encrypt_time:.2f}s). Payload: ~{len(encrypted_payload_json)/1024:.1f} KB")

    success = submit_encrypted_update(target_round, encrypted_payload_json)
    if success: current_client_round = target_round; logger.info(f"--- Completed Round {target_round} ({time.time()-start_round_time:.1f}s) ---")
    else: logger.warning(f"Failed submit update round {target_round}.")
    return success

def main_loop():
    global current_client_round
    logger.info(f"--- Starting Client: {CLIENT_ID} ---"); logger.info(f"Server URL: {SERVER_URL}")
    max_retries=5; retry_delay=5
    for attempt in range(max_retries):
        if register_with_server(): break
        logger.warning(f"Reg fail (attempt {attempt+1}/{max_retries}). Retry in {retry_delay}s...")
        time.sleep(retry_delay); retry_delay = min(retry_delay * 1.5, 45)
    else: logger.critical("Max reg retries. Exit."); sys.exit(1)
    logger.info("Registration successful. Start main loop.")
    processed_rounds=set(); consecutive_status_failures=0; max_status_failures=6
    while True:
        if not check_server_status():
            consecutive_status_failures += 1; logger.warning(f"Status check fail ({consecutive_status_failures}/{max_status_failures}).")
            if consecutive_status_failures >= max_status_failures: logger.error("Server unreachable. Exit."); break
            time.sleep(15); continue
        else: consecutive_status_failures = 0
        server_state=server_status.get("state","UNKNOWN"); server_round=server_status.get("current_round",-1)
        if server_state == "FINISHED": logger.info("Server FINISHED. Exit."); break
        elif server_state == "RUNNING":
            if server_round > current_client_round and server_round not in processed_rounds:
                logger.info(f"New server round {server_round}.")
                try: success = run_client_round(server_round); processed_rounds.add(server_round)
                except Exception as e: logger.error(f"Error round {server_round}: {e}", exc_info=True); processed_rounds.add(server_round); time.sleep(5)
            else: logger.debug(f"Wait. Server round {server_round}.")
        else: logger.info(f"Server state '{server_state}'. Wait for RUNNING.")
        num_rounds_config = server_status.get("num_rounds_configured", -1)
        if num_rounds_config > 0 and current_client_round >= num_rounds_config - 1: logger.info(f"Completed last round ({current_client_round}). Exit."); break
        time.sleep(10 + random.uniform(-1, 1))

if __name__ == '__main__':
    client_dir = os.path.dirname(__file__)
    from .config import DATASET_PATH # Import locally to avoid circular import if config uses logger
    absolute_dataset_path = os.path.join(client_dir, DATASET_PATH)
    if not os.path.exists(absolute_dataset_path): logger.critical(f"Dataset file not found at {absolute_dataset_path}. Client cannot start."); sys.exit(1)
    try: main_loop()
    except KeyboardInterrupt: logger.info("Client interrupted.")
    except Exception as e: logger.critical(f"Client main loop error: {e}", exc_info=True)
    finally: logger.info(f"--- Client {CLIENT_ID} Stopped ---"); sys.exit(0)
# client/local_trainer.py
import numpy as np
import logging
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers

from .config import LOCAL_EPOCHS, BATCH_SIZE, LEARNING_RATE # LEARNING_RATE now used

logger = logging.getLogger(__name__)

model_layer_shapes = []
model_layer_param_counts = []

# In client/local_trainer.py AND server/model_manager.py
def create_mlp_model(feature_count):
    model = keras.Sequential([
        layers.InputLayer(input_shape=(feature_count,)),
        layers.Dense(16, activation='relu', kernel_regularizer=tf.keras.regularizers.l2(0.001)), # 16 units
        layers.Dropout(0.2),
        layers.Dense(1, activation='sigmoid')
    ])
    # ... rest of compile ...
    logger.info(f"Created VERY SIMPLE MLP (16 units). Input: {feature_count}, Params: {model.count_params()}")
    return model

def get_model_weights(model: keras.Model):
    global model_layer_shapes, model_layer_param_counts
    model_layer_shapes = [] ; model_layer_param_counts = []
    flat_weights = []
    for layer_weights in model.get_weights():
        model_layer_shapes.append(layer_weights.shape)
        model_layer_param_counts.append(layer_weights.size)
        flat_weights.extend(layer_weights.flatten().tolist())
    return np.array(flat_weights)

def set_model_weights(model: keras.Model, flat_weights: np.ndarray, feature_count: int):
    global model_layer_shapes, model_layer_param_counts
    if not model_layer_shapes:
        logger.warning("Client: Model layer shapes unknown. Inferring from a temp model.")
        dummy_model = create_mlp_model(feature_count)
        get_model_weights(dummy_model) # Populates shapes
        del dummy_model
        if not model_layer_shapes: raise ValueError("Cannot set weights: layer shapes unknown.")

    expected_total_params = sum(model_layer_param_counts)
    if len(flat_weights) != expected_total_params:
        logger.error(f"Weight length mismatch. Expected {expected_total_params} (based on cached shapes {model_layer_shapes}), got {len(flat_weights)}")
        # If this error occurs, it means server sent weights from a DIFFERENT architecture
        # than what the client is expecting based on its 'create_mlp_model'
        raise ValueError(f"Incorrect number of weights. Expected {expected_total_params}, got {len(flat_weights)}")

    new_weights_list = [] ; current_pos = 0
    for shape, count in zip(model_layer_shapes, model_layer_param_counts):
        layer_flat_weights = flat_weights[current_pos : current_pos + count]
        new_weights_list.append(layer_flat_weights.reshape(shape))
        current_pos += count
    model.set_weights(new_weights_list)
    logger.debug("MLP model weights set.")
    return model


def train_local_model(global_flat_weights, X_train, y_train, client_id, feature_count):
    if X_train is None or y_train is None: logger.error("Training data is None."); return None
    if X_train.shape[0] == 0: logger.warning("No training data."); return None
    if X_train.shape[1] != feature_count: logger.error(f"Feature count mismatch."); return None
    if len(np.unique(y_train)) < 2: logger.warning(f"Only one class in training data ({np.unique(y_train)}).")

    local_model = create_mlp_model(feature_count)
    try:
        # Ensure model_layer_shapes are populated based on the structure of global_flat_weights
        # This is critical if the client is starting and doesn't have cached shapes.
        if not model_layer_shapes or sum(model_layer_param_counts) != len(global_flat_weights):
            logger.info("Client: Deriving layer shapes from received global_flat_weights using a temp model for set_weights.")
            temp_model_for_shapes = create_mlp_model(feature_count) # Create a model of the expected ARCHITECTURE
            get_model_weights(temp_model_for_shapes) # This call should populate shapes matching the architecture
            # Now, model_layer_shapes global variable should match the *client's* create_mlp_model definition.
            # If global_flat_weights came from a *different* server architecture, set_model_weights will fail.
            del temp_model_for_shapes

        set_model_weights(local_model, global_flat_weights, feature_count)
        logger.info(f"Client {client_id}: Initialized local MLP with global weights.")
    except Exception as e:
         logger.error(f"Client {client_id}: Error setting initial MLP weights: {e}. Cannot proceed.", exc_info=True)
         return None

    logger.info(f"Client {client_id}: Starting local MLP training on {len(X_train)} samples (Epochs: {LOCAL_EPOCHS}, Batch: {BATCH_SIZE}).")
    try:
        history = local_model.fit(X_train, y_train, epochs=LOCAL_EPOCHS, batch_size=BATCH_SIZE, verbose=0)
        # Log client-side training metrics
        final_accuracy = history.history.get('accuracy', [np.nan])[-1]
        final_loss = history.history.get('loss', [np.nan])[-1]
        final_auc = history.history.get('auc', [np.nan])[-1] # Keras metric name
        logger.info(f"Client {client_id}: Local MLP training complete. Acc: {final_accuracy:.4f}, Loss: {final_loss:.4f}, AUC: {final_auc:.4f}")

        new_local_flat_weights = get_model_weights(local_model)
        weight_difference = new_local_flat_weights - global_flat_weights
        logger.debug(f"Calculated MLP weight difference. Norm: {np.linalg.norm(weight_difference):.4f}")
        return weight_difference
    except Exception as e:
        logger.error(f"Client {client_id}: Error during local MLP training: {e}", exc_info=True)
        return np.zeros_like(global_flat_weights)
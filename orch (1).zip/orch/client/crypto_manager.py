# client/crypto_manager.py
import phe as paillier
import json
import logging
import numpy as np

logger = logging.getLogger(__name__)

public_key = None
precision_factor = None # Set dynamically

def set_crypto_params(pub_key_json, prec_factor):
    """Sets the Paillier public key and precision factor received from the server."""
    global public_key, precision_factor
    try:
        n_val = pub_key_json.get('n')
        if n_val is None: raise ValueError("Public key JSON missing 'n'.")
        n = int(n_val); public_key = paillier.PaillierPublicKey(n=n)
        precision_factor = int(prec_factor)
        logger.info(f"Public key and precision factor ({precision_factor}) set.")
    except Exception as e:
        logger.error(f"Failed set crypto params. Key:{pub_key_json}, Prec:{prec_factor}. Err:{e}", exc_info=True)
        public_key = None; precision_factor = None

def get_public_key():
    if public_key is None: raise ValueError("Public key not set.")
    return public_key

def get_precision_factor():
     if precision_factor is None: raise ValueError("Precision factor not set.")
     return precision_factor

def _serialize_encrypted_number(enc_num):
    return {'ciphertext': str(enc_num.ciphertext(be_secure=False)), 'exponent': enc_num.exponent}

def encrypt_vector(int_vector):
    """Encrypts a numpy vector of integers."""
    pub_key = get_public_key(); encrypted_vector_list = []
    for x in int_vector:
        try:
            # Encrypt raw integer, let phe handle it
            encrypted_num = pub_key.encrypt(int(x))
            encrypted_vector_list.append(_serialize_encrypted_number(encrypted_num))
        except OverflowError: max_val=pub_key.n//2; logger.error(f"Overflow encrypting {int(x)}. Max ~{max_val}."); raise
        except Exception as e: logger.error(f"Encryption fail value {x}: {e}", exc_info=True); raise
    return encrypted_vector_list

def encrypt_value(value):
    """Encrypts a single integer value."""
    pub_key = get_public_key()
    if not isinstance(value, (int, np.integer)): raise TypeError(f"Value must be int, got {type(value)}")
    try:
        encrypted_value = pub_key.encrypt(int(value)) # Let phe handle int
        return _serialize_encrypted_number(encrypted_value)
    except OverflowError: max_val=pub_key.n//2; logger.error(f"Overflow encrypting {int(value)}. Max ~{max_val}."); raise
    except Exception as e: logger.error(f"Encryption fail value {value}: {e}", exc_info=True); raise

def encrypt_weighted_update_and_sample_count(scaled_weighted_difference_vector, sample_count):
    """Encrypts scaled/weighted update vector and sample count."""
    logger.debug(f"Encrypting vector (shape {scaled_weighted_difference_vector.shape}) and count ({sample_count})")
    encrypted_vector_list = encrypt_vector(scaled_weighted_difference_vector)
    encrypted_sample_count_dict = encrypt_value(sample_count)
    payload = {"encrypted_weighted_vector": encrypted_vector_list, "encrypted_sample_count": encrypted_sample_count_dict}
    return json.dumps(payload)
# client/data_loader.py
import pandas as pd
import numpy as np
import logging
import os
import sys
from sklearn.preprocessing import StandardScaler

# Assuming config is imported or values are passed
from .config import DATASET_PATH, TARGET_COLUMN, FEATURE_COUNT, NUM_ROUNDS, SAMPLES_PER_ROUND_SLICE

logger = logging.getLogger(__name__)

# --- Load Full Dataset Locally ---
full_local_dataset = None
absolute_dataset_path = None # Store path for logging
try:
    client_dir = os.path.dirname(__file__)
    absolute_dataset_path = os.path.join(client_dir, DATASET_PATH)
    if not os.path.exists(absolute_dataset_path):
         logger.critical(f"CRITICAL: Local dataset CSV not found at: {absolute_dataset_path}")
    else:
        full_local_dataset = pd.read_csv(absolute_dataset_path)
        logger.info(f"Client loaded local dataset from {absolute_dataset_path}. Shape: {full_local_dataset.shape}")
except Exception as e:
    logger.critical(f"CRITICAL: Failed to load or parse local dataset {absolute_dataset_path}: {e}", exc_info=True)
    full_local_dataset = None


def get_client_round_data_slice(client_id, round_num):
    """
    Selects a slice of the locally loaded dataset based on the round number and client ID,
    preprocessses, and scales it. Logs the slice details.
    """
    if full_local_dataset is None:
        logger.error(f"Cannot get data slice for {client_id}: Local dataset not loaded.")
        return None, None

    try:
        num_total_samples = len(full_local_dataset)
        if num_total_samples == 0: logger.warning("Local dataset is empty."); return np.empty((0, FEATURE_COUNT)), np.empty((0,), dtype=int)
        if NUM_ROUNDS <= 0: logger.error("NUM_ROUNDS must be positive for slicing."); return None, None

        # --- MODIFIED SLICING LOGIC ---
        # This part of the logic was for selecting from round chunks and then taking SAMPLES_PER_ROUND_SLICE.
        # If SAMPLES_PER_ROUND_SLICE is set, we should just sample that many from the whole dataset.
        # If SAMPLES_PER_ROUND_SLICE is None/0, then we use the proportional round chunk.

        if SAMPLES_PER_ROUND_SLICE and SAMPLES_PER_ROUND_SLICE > 0:
            num_samples_to_select = min(SAMPLES_PER_ROUND_SLICE, num_total_samples)
            # Ensure seed is valid for numpy
            seed_val = abs(hash(client_id + str(round_num))) % (2**32)
            client_round_data_df = full_local_dataset.sample(n=num_samples_to_select, random_state=seed_val)
            logger.info(f"Client {client_id} using data slice for round {round_num}: "
                        f"Randomly selected {len(client_round_data_df)} samples.")
        else:
            # Proportional chunking logic (as before, but ensure seed is handled if we ever re-introduce randomness here)
            samples_per_round_chunk = num_total_samples // NUM_ROUNDS
            start_offset_for_round = round_num * samples_per_round_chunk
            end_offset_for_round = (round_num + 1) * samples_per_round_chunk if round_num < NUM_ROUNDS - 1 else num_total_samples
            num_samples_in_round_chunk = end_offset_for_round - start_offset_for_round

            if num_samples_in_round_chunk <= 0:
                 logger.warning(f"No samples calculated for round {round_num} chunk. Using full dataset as fallback.")
                 client_round_data_df = full_local_dataset.copy()
            else:
                # Deterministic offset within the round's chunk (as before)
                client_hash = int.from_bytes(client_id.encode(), 'little')
                max_offset = max(0, num_samples_in_round_chunk - 1) # Allow offset up to almost full chunk size
                client_offset = client_hash % (max_offset + 1) if max_offset >=0 else 0

                start_index_in_full = (start_offset_for_round + client_offset) % num_total_samples
                # This logic assumes we take a chunk of size 'num_samples_in_round_chunk'
                # It's better to just take the predefined chunk for the round
                # and let client_offset shift *within* it or ensure distinct chunks
                # For simplicity, let's use the direct chunk for the round, and client_id influences the *sampling*
                # IF we were to further subsample from this chunk.
                # The current simpler approach with SAMPLES_PER_ROUND_SLICE handles this.
                # If SAMPLES_PER_ROUND_SLICE is not set, we just use the chunk.

                # Let's simplify the "proportional chunk" logic to be a direct slice
                # to avoid complex indexing if SAMPLES_PER_ROUND_SLICE is not used.
                actual_start = start_offset_for_round
                actual_end = end_offset_for_round
                slice_indices = list(range(actual_start, actual_end))
                client_round_data_df = full_local_dataset.iloc[slice_indices].copy()

                logger.info(f"Client {client_id} using data slice for round {round_num}: "
                            f"Selected proportional chunk, {len(client_round_data_df)} samples "
                            f"(Indices: {actual_start} to {actual_end-1}).")

        # --- END MODIFIED SLICING LOGIC ---

        if client_round_data_df.empty:
             logger.warning(f"Client {client_id} round {round_num}: Slice is empty.")
             return np.empty((0, FEATURE_COUNT)), np.empty((0,), dtype=int)

        # --- 2. Preprocessing (on the slice) ---
        if TARGET_COLUMN not in client_round_data_df.columns: logger.error(f"Target '{TARGET_COLUMN}' not found."); return None, None
        y_slice = client_round_data_df[TARGET_COLUMN].values.astype(int)
        X_slice_df = client_round_data_df.drop(columns=[TARGET_COLUMN])

        if X_slice_df.isnull().sum().sum() > 0:
            logger.warning("Missing values in slice. Filling with means/modes.")
            for col in X_slice_df.columns[X_slice_df.isnull().any()]:
                if pd.api.types.is_numeric_dtype(X_slice_df[col]): X_slice_df[col].fillna(X_slice_df[col].mean(), inplace=True)
                else: X_slice_df[col].fillna(X_slice_df[col].mode()[0] if not X_slice_df[col].mode().empty else 'Unknown', inplace=True)

        if X_slice_df.shape[1] != FEATURE_COUNT: logger.error(f"Feature count mismatch! Expected {FEATURE_COUNT}, got {X_slice_df.shape[1]}."); return None, None
        X_slice_raw = X_slice_df.values

        # --- 3. Scaling (on the slice) ---
        scaler = StandardScaler()
        X_slice_scaled = scaler.fit_transform(X_slice_raw)

        logger.info(f"Slice preprocessing complete. Scaled shape: {X_slice_scaled.shape}")
        return X_slice_scaled, y_slice

    except Exception as e:
        logger.error(f"Error get/process data slice for C:{client_id}, R:{round_num}: {e}", exc_info=True)
        return None, None
